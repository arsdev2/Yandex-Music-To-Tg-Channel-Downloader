Yandex-Music-To-Tg-Channel-Downloader
=====================================

Скачает музыку из яндекс музыки со всех плейлистов пользователя и загрузит в телеграмм канал

.. image:: https://img.shields.io/pypi/v/yandex-music.svg
   :target: https://pypi.org/project/yandex-music/
   :alt: Версия пакета PyPi

.. image:: https://img.shields.io/badge/python-3.6%20|%203.7%20|%203.8-blue.svg
   :target: https://pypi.org/project/yandex-music/
   :alt: Поддерживаемые Python версии

.. image:: https://codecov.io/gh/MarshalX/yandex-music-api/branch/development/graph/badge.svg
   :target: https://github.com/arsdev2/Yandex-Music-To-Tg-Channel-Downloader
   :alt: Покрытие кода тестами

.. image:: https://api.codacy.com/project/badge/Grade/27011a5a8d9f4b278d1bfe2fe8725fed
   :target: https://github.com/arsdev2/Yandex-Music-To-Tg-Channel-Downloader
   :alt: Качество кода

.. image:: https://github.com/MarshalX/yandex-music-api/workflows/Full%20test/badge.svg
   :target: https://github.com/arsdev2/Yandex-Music-To-Tg-Channel-Downloader
   :alt: Статус тестов

.. image:: https://img.shields.io/badge/license-LGPLv3-lightgrey.svg
   :target: https://www.gnu.org/licenses/lgpl-3.0.html
   :alt: Лицензия LGPLv3


==========
How to use
==========

Мин. версия Python - 3.6


Для работы нужно установить эту библиотеку

Запустить команду

.. code:: shell

    $ pip install yandex-music --upgrade

В файле config.ini вписать свой токен от бота, логин и пароль от яндекс музыки


Добавить бота на канал как админа


Для первого запуска использовать run_first_time.sh(или run_first_time.bat для Windows)


Для следующих - run.bat (или run.sh для Linux)

После первого запуска скрипта, канал можно закрывать.
 
